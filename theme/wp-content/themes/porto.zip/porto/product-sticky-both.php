<?php
/*
 * Template Name: Porto - Product-sticky-both
 */

get_header();

get_template_part('content/126','content');
get_template_part('content/128','content');

get_footer();

?>
