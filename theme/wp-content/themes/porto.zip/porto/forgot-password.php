
<?php
/*
 * Template Name: Porto - forgot-password
 * Template Post Type: post, page, product
 */


get_header();

get_template_part('content/124','content');
get_footer();

?>
