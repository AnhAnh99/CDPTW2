<?php
/*
 * Template Name: Porto - Category-Horizontal-Filter-2
 */

get_header();

get_template_part('content/125','content');

get_footer();

?>
