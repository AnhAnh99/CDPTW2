<?php
/*
 * Template Name: Porto - Category
 */

get_header();

get_template_part('content/category','content');

get_footer();

?>
