<?php


/**
 * Enqueue scripts and styles
 */
function your_theme_enqueue_scripts()
{
    // all styles
    wp_enqueue_style('bootstrap', get_stylesheet_directory_uri() . '/css/bootstrap-v3.3.6.min.css');
    wp_enqueue_style('font-awesome', get_stylesheet_directory_uri() . '/css/font-awesome.min.css');
    wp_enqueue_style('swiper', get_stylesheet_directory_uri() . '/css/swiper.min.css');
    wp_enqueue_style('style', get_stylesheet_directory_uri() . '/style.css');

    /*Partner 1*/
    if ( is_page_template( 'horizontal-thumbnails.php' ) ) {
        wp_enqueue_style( '332-style', get_template_directory_uri() . '/css/332.css' );
        wp_enqueue_style( '333-style', get_template_directory_uri() . '/css/333.css' );
        wp_enqueue_style( '334-style', get_template_directory_uri() . '/css/334.css' );
    }
    if ( is_page_template( 'product-sticky-tag.php' ) ) {
         wp_enqueue_style( '332-style', get_template_directory_uri() . '/css/332.css' );
        wp_enqueue_style( '331-style', get_template_directory_uri() . '/css/331.css' );
        wp_enqueue_style( '334-style', get_template_directory_uri() . '/css/334.css' );
    }
    if ( is_page_template( 'category-flex-grid1.php' ) ) {
        wp_enqueue_style( '335-style', get_template_directory_uri() . '/css/335.css' );
    }
    if ( is_page_template( 'viewcart.php' ) ) {
        wp_enqueue_style( '336-style', get_template_directory_uri() . '/css/336.css' );
        wp_enqueue_style( '337-style', get_template_directory_uri() . '/css/337.css' );
    }
    if ( is_page_template( 'blog.php' ) ) {
        wp_enqueue_style( '338-style', get_template_directory_uri() . '/css/338.css' );
        wp_enqueue_style( '339-style', get_template_directory_uri() . '/css/339.css' );
    }
    if ( is_page_template( 'checkout-shipping-2.php' ) ) {
        wp_enqueue_style( '340-style', get_template_directory_uri() . '/css/340.css' );
    }
    if ( is_page_template( 'my-account.php' ) ) {
        wp_enqueue_style( '341-style', get_template_directory_uri() . '/css/341.css' );
    }

    /*Partner 2*/
    if ( is_page_template( 'category.php' ) ) {
        wp_enqueue_style( '121-style', get_template_directory_uri() . '/css/121.css' );
        wp_enqueue_style( '122-style', get_template_directory_uri() . '/css/122.css' );
    }
    if ( is_page_template( 'category-horizontal-filter2.php' ) ) {
        wp_enqueue_style( '154-style', get_template_directory_uri() . '/css/154.css' );
    }
    if ( is_page_template( 'checkout.php' ) ) {
        wp_enqueue_style( '132-style', get_template_directory_uri() . '/css/132.css' );
        wp_enqueue_style( '133-style', get_template_directory_uri() . '/css/133.css' );
    }
    if ( is_page_template( 'contact.php' ) ) {
        wp_enqueue_style( '148-style', get_template_directory_uri() . '/css/148.css' );
        wp_enqueue_style( '149-style', get_template_directory_uri() . '/css/149.css' );
    }
    if ( is_page_template( 'product-sticky-both.php' ) ) {
        wp_enqueue_style( '155-style', get_template_directory_uri() . '/css/155.css' );
        wp_enqueue_style( '157-style', get_template_directory_uri() . '/css/157.css' );
    }
    if ( is_page_template( 'product-sticky-info.php' ) ) {
        wp_enqueue_style( '156-style', get_template_directory_uri() . '/css/156.css' );
        wp_enqueue_style( '157-style', get_template_directory_uri() . '/css/157.css' );
    }


    /*Partner 3*/
    if (is_home()) {
        wp_enqueue_style( '201-style', get_template_directory_uri() . '/css/201.css' );
        wp_enqueue_style( '213-style', get_template_directory_uri() . '/css/213.css' );
        wp_enqueue_style( '202-style', get_template_directory_uri() . '/css/202.css' );
        wp_enqueue_style( '203-style', get_template_directory_uri() . '/css/203.css' );
        wp_enqueue_style( '204-style', get_template_directory_uri() . '/css/204.css' );
        wp_enqueue_style( '205-style', get_template_directory_uri() . '/css/205.css' );
        wp_enqueue_style( '206-style', get_template_directory_uri() . '/css/206.css' );
    }
    if ( is_page_template( 'category-flex-grid1.php' ) ) {
        wp_enqueue_style( '207-style', get_template_directory_uri() . '/css/207.css' );
        wp_enqueue_style( '208-style', get_template_directory_uri() . '/css/208.css' );
    }
    if ( is_page_template( 'product-full-width.php' ) ) {
        wp_enqueue_style( '210-style', get_template_directory_uri() . '/css/210.css' );
        wp_enqueue_style( '211-style', get_template_directory_uri() . '/css/211.css' );
    }
    if ( is_page_template( 'single1.php' ) ) {
        wp_enqueue_style( '209-style', get_template_directory_uri() . '/css/209.css' );
        wp_enqueue_style( '214-style', get_template_directory_uri() . '/css/214.css' );
        wp_enqueue_style( '215-style', get_template_directory_uri() . '/css/215.css' );
        wp_enqueue_style( '339-style', get_template_directory_uri() . '/css/339.css' );
    }
    if ( is_page_template( 'about.php' ) ) {
        wp_enqueue_style( '140-style', get_template_directory_uri() . '/css/140.css' );
        wp_enqueue_style( '141-style', get_template_directory_uri() . '/css/141.css' );
        wp_enqueue_style( '142-style', get_template_directory_uri() . '/css/142.css' );
        wp_enqueue_style( '144-style', get_template_directory_uri() . '/css/144.css' );
    }
    if ( is_page_template( 'category-8col.php' ) ) {
        wp_enqueue_style( '155-style', get_template_directory_uri() . '/css/155.css' );
    }
    if ( is_page_template( 'dashboard.php' ) ) {
        wp_enqueue_style( '137-style', get_template_directory_uri() . '/css/137.css' );
        wp_enqueue_style( '138-style', get_template_directory_uri() . '/css/138.css' );
    }
    if ( is_page_template( 'forgot-password.php' ) ) {
        wp_enqueue_style( '151-style', get_template_directory_uri() . '/css/151.css' );
    }
}

add_action('wp_enqueue_scripts', 'your_theme_enqueue_scripts');


function add_custom_script()
{
    wp_register_script('jquery', get_template_directory_uri() . '/js/jquery.min.js', array('jquery'));
    wp_register_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'));
    wp_register_script('bundle', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array('jquery'));

    wp_register_script('main', get_template_directory_uri() . '/js/main.min.js', array('jquery'));
    wp_register_script('plugins', get_template_directory_uri() . '/js/plugins.min.js', array('jquery'));
    wp_register_script('swiper', get_template_directory_uri() . '/js/swiper.min.js', array('jquery'));


    /*Phi*/
    wp_register_script('nouislider', get_template_directory_uri() . '/js/nouislider.min.js', array('jquery'));
    wp_enqueue_script('nouislider');
    /*Phi-end*/

    wp_enqueue_script('jquery');
    wp_enqueue_script('bundle');
    wp_enqueue_script('main');
    wp_enqueue_script('plugins');
    wp_enqueue_script('swiper');
 
}

add_action('wp_enqueue_scripts', 'add_custom_script');

/**====== Duy functions ======**/
function getPosts(){

}

@ini_set('upload_max_size', '120M');
@ini_set('post_max_size', '120M');
@ini_set('max_execution_time', '300');
