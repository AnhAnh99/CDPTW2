jQuery(document).ready(function() {
    var swiper = new Swiper('.swiper-container-201', {
        speed: 1000,
        loop: true,
        autoplay: {
            delay: 1000,
        },
    });
});