var swiper = new Swiper('.swiper-container-206', {
    speed: 1000,
    loop: true,
    slidesPerView: 2,
    spaceBetween: 30,
    autoplay: {
        delay: 1000,
    },
});