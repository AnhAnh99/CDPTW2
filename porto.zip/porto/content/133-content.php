<div class="type-133">
    <div class="promo-section" style="background-image: url(<?php bloginfo('template_url'); ?>/images/promo-bg.jpg)">
        <div class="container">
            <h3>fashion show collection</h3>
            <a href="#" class="btn btn-dark">Shop Now</a>
        </div><!-- End .container -->
    </div>
    <div class="container">
        <div class="swiper-container swiper-container-205" style="height: 44.9625px;">
            <div class="swiper-wrapper"
                style="transform: translate3d(-1584px, 0px, 0px); transition: 0.25s; width: 3366px;">
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/3.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/4.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/5.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/2.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/1.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/1.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/2.png" alt="logo">
                    </a></div>
                <div class="swiper-slide" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/3.png" alt="logo">
                    </a></div>
                <div class="swiper-slide active" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/4.png" alt="logo">
                    </a></div>
                <div class="swiper-slide active" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/5.png" alt="logo">
                    </a></div>
                <div class="swiper-slide active" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/2.png" alt="logo">
                    </a></div>
                <div class="swiper-slide active" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/1.png" alt="logo">
                    </a></div>
                <div class="swiper-slide cloned active" style="width: 178px; margin-right: 20px;"><a href="#"
                        class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/1.png" alt="logo">
                    </a></div>
                <div class="swiper-slide cloned" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/2.png" alt="logo">
                    </a></div>
                <div class="swiper-slide cloned" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/3.png" alt="logo">
                    </a></div>
                <div class="swiper-slide cloned" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/4.png" alt="logo">
                    </a></div>
                <div class="swiper-slide cloned" style="width: 178px; margin-right: 20px;"><a href="#" class="partner">
                        <img src="<?php bloginfo('template_url'); ?>/images/5.png" alt="logo">
                    </a></div>
            </div>
        </div>
    </div><!-- End .container -->
</div>