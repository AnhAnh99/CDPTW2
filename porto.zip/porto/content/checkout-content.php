<div class="page-wrapper">
    <main class="main">
        <div class="container">
            <ul class="checkout-progress-bar">
                <li>
                    <span>Shipping</span>
                </li>
                <li class="active">
                    <span>Review &amp; Payments</span>
                </li>
            </ul>
            <div class="row">
                <?php get_template_part('content/132','content') ?>
                <?php get_template_part('content/133','content') ?>
            </div><!-- End .row -->
        </div><!-- End .container -->
        <div class="mb-6"></div><!-- margin -->
    </main>
</div>