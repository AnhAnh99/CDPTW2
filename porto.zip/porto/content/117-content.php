<div class="type-117">
<div class="page-header page-header-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/images/img.jpg');">
                <div class="container">
                    <h1><span>ABOUT US</span>
                        OUR COMPANY</h1>
                    <a href="contact.html" class="btn btn-dark">Contact</a>
                </div><!-- End .container -->
            </div>
</div>