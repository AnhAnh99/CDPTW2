<?php
/*
 * Template Name: Porto - product-full-width
 * Template Post Type: post, page, product
 */

get_header();

get_template_part('content/137','content');
get_template_part('content/138','content');

get_footer();

?>
<script src="<?php bloginfo('template_url'); ?>/js/swiper.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/138.js"></script>
