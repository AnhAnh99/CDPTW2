<?php
/*
 * Template Name: Porto - Product-sticky-info
 */

get_header();

get_template_part('content/127','content');
get_template_part('content/128','content');

get_footer();

?>