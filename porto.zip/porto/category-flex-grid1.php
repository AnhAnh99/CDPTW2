<?php
/*
 * Template Name: Porto - Cateogry Flex Grid1
 * Template Post Type: post, page, product
 */

get_header();

get_template_part('content/135','content');
get_template_part('content/136','content');

get_footer();

?>
