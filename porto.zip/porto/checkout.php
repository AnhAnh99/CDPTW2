<?php
/*
 * Template Name: Porto - Checkout
 */

get_header();

get_template_part('content/checkout','content');

get_footer();

?>
