<?php
/*
 * Template Name: Porto - contact
 * Template Post Type: post, page, product
 */

get_header();

get_template_part('content/122','content');
get_template_part('content/123','content');

get_footer();

?>
<script src="<?php bloginfo('template_url'); ?>/js/map.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDc3LRykbLB-y8MuomRUIY0qH5S6xgBLX4"></script>
