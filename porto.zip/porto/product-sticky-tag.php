
<?php
/*
 * Template Name: Porto - product-sticky-tag
 * Template Post Type: post, page, product
 */
get_header();


/*Nội dung trang*/
get_template_part('content/144','content');

get_footer();
?>
<script src="<?php bloginfo('template_url'); ?>/js/144.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/145.js"></script>