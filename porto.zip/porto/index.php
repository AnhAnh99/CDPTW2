

<?php
/*
 * Template Name: Porto - index
 * Template Post Type: post, page, product
 */
get_header();


/*Nội dung trang*/
get_template_part('content/129','content');
get_template_part('content/130','content');
get_template_part('content/131','content');
get_template_part('content/141','content');
get_template_part('content/132','content');
get_template_part('content/133','content');
get_template_part('content/134','content');

get_footer();
?>

<script src="<?php bloginfo('template_url'); ?>/js/swiper.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/141.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/134.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/135.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/129.js"></script>

