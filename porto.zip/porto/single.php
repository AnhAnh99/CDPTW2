<?php
/*
 * Template Name: Porto - Featured Article
 * Template Post Type: post, page, product
 */

get_header();


get_footer();

?>


