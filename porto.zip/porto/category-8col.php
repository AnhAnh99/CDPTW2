<?php
/*
 * Template Name: Porto - Category-8col
 * Template Post Type: post, page, product
 */


get_header();

get_template_part('content/126','content');
get_footer();

?>
