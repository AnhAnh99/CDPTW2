
<?php
/*
 * Template Name: Porto - horizontal-thumbnails
 * Template Post Type: post, page, product
 */
get_header();


/*Nội dung trang*/
get_template_part('content/146','content');

get_footer();


?>

<script src="<?php bloginfo('template_url'); ?>/js/146.js"></script>
