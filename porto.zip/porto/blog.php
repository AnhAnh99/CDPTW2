
<?php
/*
 * Template Name: Porto - blog
 * Template Post Type: post, page, product
 */
get_header();


/*Nội dung trang*/
get_template_part('content/151','content');

get_footer();


?>