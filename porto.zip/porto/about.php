<?php
/*
 * Template Name: Porto - About
 * Template Post Type: post, page, product
 */


get_header();

get_template_part('content/117','content');
get_template_part('content/118','content');
get_template_part('content/119','content');
get_template_part('content/121','content');
get_footer();

?>
