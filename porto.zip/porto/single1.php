<?php
/*
 * Template Name: Porto - Single1
 * Template Post Type: post, page, product
 */

get_header();

get_template_part('content/137','content');

get_footer();

?>
<script src="<?php bloginfo('template_url'); ?>/js/137.js"></script>
