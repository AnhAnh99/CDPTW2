
<?php
/*
 * Template Name: Porto - checkout-shipping-2
 * Template Post Type: post, page, product
 */
get_header();


/*Nội dung trang*/
get_template_part('content/152','content');

get_footer();


?>